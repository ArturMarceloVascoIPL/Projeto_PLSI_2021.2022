<?php
Yii::setAlias('api', dirname(dirname(__DIR__)) . '/api');
