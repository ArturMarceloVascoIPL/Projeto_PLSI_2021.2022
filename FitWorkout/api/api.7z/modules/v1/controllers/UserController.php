<?php

namespace app\api\modules\v1\controllers;
use yii\rest\ActiveController;

class UserController extends ActiveController
{
    public $modelClass = 'app\models\User';
}